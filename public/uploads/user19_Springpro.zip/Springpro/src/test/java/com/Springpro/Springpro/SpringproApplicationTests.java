package com.Springpro.Springpro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringproApplicationTests {

	@Test
	void contextLoads() {
	}

}
